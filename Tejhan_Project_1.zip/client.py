import socket 
  
  def Main(): 
    host = '127.0.0.1'
  
    # Give the port number to connect 
    port = 8090
  
    sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM) 
  
    # connect to server 
    sock.connect((host,port)) 
  
    
    while True: 
     #user should enter the string
        mesg=raw_input('Enter a string:')

        # message sent to server 
        sock.sendall(mesg.encode('ascii')) 
  
        # message received from server 
        string = sock.recv(1024) 
  
        # print the received message  
        print('Reverse of the string is :',str(string.decode('ascii'))) 
  
        # ask the client whether he wants to continue 
        ans = raw_input('\nDo you want to continue(y/n) :') 
        if ans == 'y': 
            continue
        else: 
            break
    # close the connection 
    sock.close() 
  
if __name__ == '__main__': 
    Main() 
