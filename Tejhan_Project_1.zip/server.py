import socket 
from _thread import *
import threading 

#threaded function 
def threaded(client): 
    while True: 
  
        # data received from client 
        string = client.recv(1024) 
        if not string: 
            print('Bye')  
            break
  
        # reverse the given string from client 
        string = string[::-1] 
  
        # send back reversed string to client 
        client.sendall(string) 
  
    # connection closed 
    client.close() 
  
  
def Main(): 
    host = "" 
   # Enter the port number which you want to connect   
    port = 8090
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
    sock.bind((host, port)) 
   # Connects to the specified port
    print("socket binded to post", port) 
  
    # put the socket into listening mode 
    sock.listen(20) 
    print("socket is listening") 
  
    # a loop until client wants to exit 
    while True: 
  
        # establish connection with client 
        client, addr = sock.accept() 
  
        # connects to different clients 
        print('Connected to :', addr[0], ':', addr[1]) 
  
        # Start a new thread  
        start_new_thread(threaded, (client,)) 
    sock.close() 
  
  
if __name__ == '__main__': 
    Main() 
